# SPK-14116021
SISTEM PENDUKUNG KEPUTUSAN Pemilihan Oleh-Oleh Khas Lampung Menggunakan Metode SAW (Simple Additive Weighting)
- Fadila Eka Noperta
