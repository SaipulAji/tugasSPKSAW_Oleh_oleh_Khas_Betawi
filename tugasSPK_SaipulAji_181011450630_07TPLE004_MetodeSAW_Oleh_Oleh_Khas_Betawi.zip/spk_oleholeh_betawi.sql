-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2022 at 10:17 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spk_pemilihan_oleh_oleh_lampung`
--

-- --------------------------------------------------------

--
-- Table structure for table `alternatif`
--

CREATE TABLE `alternatif` (
  `id_alternatif` varchar(4) NOT NULL,
  `nama_alternatif` varchar(100) NOT NULL,
  `nama_kriteria` varchar(25) NOT NULL,
  `id_ket_kriteria` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alternatif`
--

INSERT INTO `alternatif` (`id_alternatif`, `nama_alternatif`, `nama_kriteria`, `id_ket_kriteria`) VALUES
('D1', 'Dodol Betawi\r\n', 'Harga', 'H3'),
('D2', 'Dodol Betawi\r\n', 'Tekstur', 'T4'),
('D3', 'Dodol Betawi\r\n', 'Varian Rasa', 'V5'),
('K1', 'Kerak Telor\r\n', 'Harga', 'H2'),
('K2', 'Kerak Telor\r\n', 'Tekstur', 'H5'),
('K3', 'Kerak Telor\r\n', 'Varian Rasa', 'H3'),
('KK1', 'Kue Kembang Goyang\r\n', 'Harga', 'H2'),
('KK2', 'Kue Kembang Goyang\r\n', 'Tekstur', 'H5'),
('KK3', 'Kue Kembang Goyang\r\n', 'Varian Rasa', 'H5'),
('P1', 'Putu Mayang', 'Harga', 'H2'),
('P2', 'Putu Mayang', 'Tekstur', 'H3'),
('P3', 'Putu Mayang', 'Varian Rasa', 'V5'),
('R1', 'Roti Buaya\r\n', 'Harga', 'H5'),
('R2', 'Roti Buaya\r\n', 'Tekstur', 'H2'),
('R3', 'Roti Buaya\r\n', 'Varian Rasa', 'V5');

-- --------------------------------------------------------

--
-- Table structure for table `data_oleh`
--

CREATE TABLE `data_oleh` (
  `id_oleh_oleh` varchar(4) NOT NULL,
  `nama_alternatif` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_oleh`
--

INSERT INTO `data_oleh` (`id_oleh_oleh`, `nama_alternatif`) VALUES
('5', 'Dodol Betawi\r\n'),
('1', 'Kerak Telor\r\n'),
('3', 'Kue Kembang Goyang\r\n'),
('2', 'Putu Mayang'),
('4', 'Roti Buaya\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `ket_kriteria`
--

CREATE TABLE `ket_kriteria` (
  `id_ket_kriteria` varchar(4) NOT NULL,
  `nama_kriteria` varchar(25) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  `bobot_pilih` enum('-','5','4','3','2','1') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ket_kriteria`
--

INSERT INTO `ket_kriteria` (`id_ket_kriteria`, `nama_kriteria`, `keterangan`, `bobot_pilih`) VALUES
('H1', 'Harga', '< 20.000', '1'),
('H2', 'Harga', '20.001 - 50.000', '2'),
('H3', 'Harga', '50.001 - 100.000', '3'),
('H5', 'Harga', '100.001 - 300.000', '4'),
('T1', 'Tekstur', 'Sangat Basah', '1'),
('T2', 'Tekstur', 'Sangat Kering', '2'),
('T3', 'Tekstur', 'Basah', '3'),
('T4', 'Tekstur', 'Sedang', '4'),
('V2', 'Varian Rasa', 'Pahit', '2'),
('V3', 'Varian Rasa', 'Gurih', '3'),
('V4', 'Varian Rasa', 'Pedas', '4'),
('V5', 'Varian Rasa', 'Manis', '5');

-- --------------------------------------------------------

--
-- Table structure for table `kriteria`
--

CREATE TABLE `kriteria` (
  `id_kriteria` varchar(4) NOT NULL,
  `nama_kriteria` varchar(25) NOT NULL,
  `tipe_kriteria` enum('Cost','Benefit') NOT NULL,
  `bobot_acuan` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kriteria`
--

INSERT INTO `kriteria` (`id_kriteria`, `nama_kriteria`, `tipe_kriteria`, `bobot_acuan`) VALUES
('C1', 'Harga', 'Cost', 0.3),
('C2', 'Tekstur', 'Benefit', 0.17),
('C3', 'Varian Rasa', 'Benefit', 0.3);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(5) NOT NULL,
  `nama_user` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `level` varchar(25) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_user`, `email`, `password`, `level`) VALUES
(5, 'Aji', 'aji@mail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'user'),
(6, 'deni', 'deni@mail.com', '3e0101ecf0d8427cf14f3f6dc2f0282d', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alternatif`
--
ALTER TABLE `alternatif`
  ADD PRIMARY KEY (`id_alternatif`),
  ADD KEY `nama_kriteria` (`nama_kriteria`),
  ADD KEY `id_ket_kriteria` (`id_ket_kriteria`),
  ADD KEY `nama_alternatif` (`nama_alternatif`);

--
-- Indexes for table `data_oleh`
--
ALTER TABLE `data_oleh`
  ADD PRIMARY KEY (`nama_alternatif`);

--
-- Indexes for table `ket_kriteria`
--
ALTER TABLE `ket_kriteria`
  ADD PRIMARY KEY (`id_ket_kriteria`),
  ADD KEY `nama_kriteria` (`nama_kriteria`);

--
-- Indexes for table `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`nama_kriteria`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `alternatif`
--
ALTER TABLE `alternatif`
  ADD CONSTRAINT `fk_alternatif_id_ket_kriteria` FOREIGN KEY (`id_ket_kriteria`) REFERENCES `ket_kriteria` (`id_ket_kriteria`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_alternatif_nama_alternatif` FOREIGN KEY (`nama_alternatif`) REFERENCES `data_oleh` (`nama_alternatif`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_alternatif_nama_kriteria` FOREIGN KEY (`nama_kriteria`) REFERENCES `kriteria` (`nama_kriteria`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ket_kriteria`
--
ALTER TABLE `ket_kriteria`
  ADD CONSTRAINT `fk_ket_kriteria_nama_kriteria` FOREIGN KEY (`nama_kriteria`) REFERENCES `kriteria` (`nama_kriteria`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
